# IMS — Interior Management System

A full-stack web application for interior design firms. All changes made in the UI are saved to a real PostgreSQL database in real time — add a client, edit a project, record an expense, and it's instantly reflected everywhere.

---

## What's Inside

| Module | What you can do |
|---|---|
| **Dashboard** | Live KPIs, revenue vs expenses chart, project status, recent activity |
| **Clients** | Add, edit, delete clients — search by name |
| **Projects** | Create projects, assign clients & employees, track status |
| **Employees** | Manage your team — roles, departments, salary |
| **Materials** | Inventory tracking with low-stock alerts |
| **Expenses** | Record and categorise expenses per project |
| **Invoices** | Generate invoices with GST calculation, track paid/pending/overdue |
| **Reports** | Charts and summaries — expense breakdown, project completion, revenue trends |

**Demo login credentials:**
- `admin` / `admin123` — full access
- `employee` / `emp123` — limited access

---

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React 19, Vite, Tailwind CSS v4, shadcn/ui, Recharts, React Query |
| Backend | Node.js 20+, Express 5 |
| Database | PostgreSQL + Drizzle ORM |
| Validation | Zod + drizzle-zod |
| Monorepo | pnpm workspaces, TypeScript 5.9 |

---

## Prerequisites

Install these before you begin:

1. **Node.js v20+** → https://nodejs.org
2. **pnpm v9+** → run `npm install -g pnpm`
3. **PostgreSQL v14+** → https://www.postgresql.org/download/

> On Windows: install PostgreSQL, then open pgAdmin or psql to create your database.
> On Mac: `brew install postgresql@16 && brew services start postgresql@16`
> On Linux: `sudo apt install postgresql && sudo service postgresql start`

---

## Setup (Step by Step)

### Step 1 — Install dependencies

```bash
pnpm install
```

### Step 2 — Create your database

Open a PostgreSQL prompt and create the database:

```sql
CREATE DATABASE ims;
```

Or from your terminal:

```bash
psql -U postgres -c "CREATE DATABASE ims;"
```

### Step 3 — Configure environment variables

Copy the example file:

```bash
cp .env.example .env
```

Open `.env` and set your database connection:

```env
DATABASE_URL=postgresql://postgres:yourpassword@localhost:5432/ims
```

Replace `yourpassword` with your actual PostgreSQL password. If you didn't set a password, try:
```
DATABASE_URL=postgresql://postgres@localhost:5432/ims
```

### Step 4 — Create database tables

```bash
DATABASE_URL=postgresql://postgres:yourpassword@localhost:5432/ims \
  pnpm --filter @workspace/db run push
```

This creates all the tables (clients, projects, employees, materials, expenses, invoices, etc.) in your PostgreSQL database.

### Step 5 — Seed sample data (recommended)

```bash
DATABASE_URL=postgresql://postgres:yourpassword@localhost:5432/ims \
  pnpm --filter @workspace/db run seed
```

This fills the database with realistic sample data — 6 clients, 7 employees, 6 projects, 8 materials, 8 expenses, 6 invoices, and 8 activity entries — so the dashboard charts and reports are meaningful from the start.

---

## Running the App

### Option A — One command (recommended)

```bash
# Make the script executable first (Mac/Linux only)
chmod +x start.sh
./start.sh
```

This starts both the API server and the frontend together.

### Option B — Two separate terminals

**Terminal 1 — API Server:**

```bash
PORT=8080 DATABASE_URL=postgresql://postgres:yourpassword@localhost:5432/ims \
  pnpm --filter @workspace/api-server run dev
```

**Terminal 2 — Frontend:**

```bash
PORT=5173 API_PORT=8080 \
  pnpm --filter @workspace/ims run dev
```

### Open the app

Go to **http://localhost:5173** in your browser.

Log in with `admin` / `admin123`.

---

## How the Database Connection Works

```
Browser (localhost:5173)
       ↓  clicks "Add Client"
React Frontend (Vite dev server)
       ↓  POST /api/clients
Vite Proxy  ──────────────────→  API Server (localhost:8080)
                                        ↓  SQL INSERT
                                 PostgreSQL Database
                                        ↓
                                 Returns saved record
       ↑  React Query refetches
Browser shows updated list
```

Every create, edit, and delete operation goes through this chain. The Vite proxy automatically forwards all `/api/*` requests to the API server — no CORS issues, no extra configuration needed.

---

## Project Structure

```
IMS-project/
├── artifacts/
│   ├── ims/                        # React + Vite frontend
│   │   ├── src/
│   │   │   ├── pages/              # Dashboard, Clients, Projects, etc.
│   │   │   ├── components/         # Layout, StatCard, PageHeader, etc.
│   │   │   └── contexts/           # AuthContext (login state)
│   │   └── vite.config.ts          # Vite config with /api proxy
│   └── api-server/                 # Express API server
│       └── src/
│           ├── routes/             # Route handlers for each module
│           └── lib/                # Logger, helpers
├── lib/
│   ├── db/                         # Database layer
│   │   └── src/
│   │       ├── schema/             # Table definitions (source of truth)
│   │       ├── index.ts            # Drizzle client
│   │       └── seed.ts             # Sample data seed script
│   ├── api-spec/                   # OpenAPI YAML specification
│   ├── api-client-react/           # Generated React Query hooks
│   └── api-zod/                    # Generated Zod validation schemas
├── .env.example                    # Environment variable template
├── start.sh                        # One-command startup script
├── pnpm-workspace.yaml             # Monorepo configuration
└── README.md
```

---

## Useful Commands

| Command | What it does |
|---|---|
| `pnpm install` | Install all dependencies |
| `pnpm --filter @workspace/db run push` | Create/update database tables |
| `pnpm --filter @workspace/db run seed` | Fill database with sample data |
| `pnpm --filter @workspace/api-server run dev` | Start API server |
| `pnpm --filter @workspace/ims run dev` | Start frontend |
| `pnpm run typecheck` | TypeScript check across all packages |

---

## Uploading to GitHub

```bash
# Initialise git (if not already done)
git init
git add .
git commit -m "Initial commit — IMS Interior Management System"

# Push to GitHub
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git branch -M main
git push -u origin main
```

> **Note:** The `.env` file is in `.gitignore` so your database credentials are never uploaded. Only `.env.example` (with no real credentials) is committed.

---

## Troubleshooting

**"DATABASE_URL must be set"**
→ Copy `.env.example` to `.env` and fill in your PostgreSQL connection string.

**"Connection refused" or "ECONNREFUSED"**
→ Make sure PostgreSQL is running: `sudo service postgresql start` (Linux) or check pgAdmin (Windows).

**"Database does not exist"**
→ Run: `psql -U postgres -c "CREATE DATABASE ims;"`

**"Port 5173 already in use"**
→ Change the frontend port: `PORT=3000 pnpm --filter @workspace/ims run dev`

**"Port 8080 already in use"**
→ Change the API port: `PORT=3001 API_PORT=3001 ...` (update both)
