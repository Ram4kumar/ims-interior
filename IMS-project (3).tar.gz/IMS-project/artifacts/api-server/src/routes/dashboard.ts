import { Router } from "express";
import { db } from "@workspace/db";
import {
  clientsTable,
  projectsTable,
  employeesTable,
  materialsTable,
  expensesTable,
  invoicesTable,
  activitiesTable,
} from "@workspace/db";
import { sql, eq, and, gte } from "drizzle-orm";

const router = Router();

router.get("/summary", async (req, res) => {
  try {
    const [
      clientCount,
      projectCount,
      ongoingCount,
      completedCount,
      allInvoices,
      allExpenses,
      lowStockCount,
    ] = await Promise.all([
      db.select({ count: sql<number>`count(*)::int` }).from(clientsTable),
      db.select({ count: sql<number>`count(*)::int` }).from(projectsTable),
      db
        .select({ count: sql<number>`count(*)::int` })
        .from(projectsTable)
        .where(eq(projectsTable.status, "ongoing")),
      db
        .select({ count: sql<number>`count(*)::int` })
        .from(projectsTable)
        .where(eq(projectsTable.status, "completed")),
      db
        .select({ status: invoicesTable.status, totalAmount: invoicesTable.amount, taxRate: invoicesTable.taxRate })
        .from(invoicesTable),
      db.select({ amount: expensesTable.amount }).from(expensesTable),
      db
        .select({ count: sql<number>`count(*)::int` })
        .from(materialsTable)
        .where(sql`quantity <= low_stock_threshold`),
    ]);

    const pendingPayments = allInvoices
      .filter((inv) => inv.status === "pending" || inv.status === "overdue")
      .reduce((sum, inv) => {
        const a = parseFloat(inv.totalAmount as string);
        const t = parseFloat(inv.taxRate as string);
        return sum + a * (1 + t / 100);
      }, 0);

    const totalRevenue = allInvoices
      .filter((inv) => inv.status === "paid")
      .reduce((sum, inv) => {
        const a = parseFloat(inv.totalAmount as string);
        const t = parseFloat(inv.taxRate as string);
        return sum + a * (1 + t / 100);
      }, 0);

    const totalExpenses = allExpenses.reduce(
      (sum, e) => sum + parseFloat(e.amount as string),
      0
    );

    res.json({
      totalClients: clientCount[0]?.count ?? 0,
      totalProjects: projectCount[0]?.count ?? 0,
      ongoingProjects: ongoingCount[0]?.count ?? 0,
      completedProjects: completedCount[0]?.count ?? 0,
      pendingPayments: Math.round(pendingPayments * 100) / 100,
      totalRevenue: Math.round(totalRevenue * 100) / 100,
      totalExpenses: Math.round(totalExpenses * 100) / 100,
      lowStockMaterials: lowStockCount[0]?.count ?? 0,
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch dashboard summary" });
  }
});

router.get("/monthly-revenue", async (req, res) => {
  try {
    const months: { month: string; revenue: number; expenses: number }[] = [];
    const now = new Date();
    for (let i = 11; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const label = d.toLocaleString("default", { month: "short", year: "2-digit" });
      const start = d.toISOString().slice(0, 7);
      const endD = new Date(d.getFullYear(), d.getMonth() + 1, 0);
      const end = endD.toISOString().slice(0, 10);

      const [revRows, expRows] = await Promise.all([
        db
          .select({ amount: invoicesTable.amount, taxRate: invoicesTable.taxRate })
          .from(invoicesTable)
          .where(
            and(
              eq(invoicesTable.status, "paid"),
              sql`issue_date >= ${start + "-01"} AND issue_date <= ${end}`
            )
          ),
        db
          .select({ amount: expensesTable.amount })
          .from(expensesTable)
          .where(sql`date >= ${start + "-01"} AND date <= ${end}`),
      ]);

      const revenue = revRows.reduce((s, r) => {
        const a = parseFloat(r.amount as string);
        const t = parseFloat(r.taxRate as string);
        return s + a * (1 + t / 100);
      }, 0);
      const expenses = expRows.reduce((s, r) => s + parseFloat(r.amount as string), 0);

      months.push({
        month: label,
        revenue: Math.round(revenue * 100) / 100,
        expenses: Math.round(expenses * 100) / 100,
      });
    }
    res.json(months);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch monthly revenue" });
  }
});

router.get("/recent-activity", async (req, res) => {
  try {
    const activities = await db
      .select()
      .from(activitiesTable)
      .orderBy(sql`created_at DESC`)
      .limit(15);
    res.json(
      activities.map((a) => ({
        id: a.id,
        type: a.type,
        description: a.description,
        createdAt: a.createdAt.toISOString(),
      }))
    );
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch recent activity" });
  }
});

router.get("/project-status-breakdown", async (req, res) => {
  try {
    const rows = await db
      .select({
        status: projectsTable.status,
        count: sql<number>`count(*)::int`,
      })
      .from(projectsTable)
      .groupBy(projectsTable.status);
    res.json(rows);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch project status breakdown" });
  }
});

export default router;
