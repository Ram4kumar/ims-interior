import { Router } from "express";
import { db } from "@workspace/db";
import { expensesTable, projectsTable, activitiesTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import {
  CreateExpenseBody,
  UpdateExpenseBody,
} from "@workspace/api-zod";

const router = Router();

async function toExpenseJson(e: typeof expensesTable.$inferSelect) {
  let projectName: string | null = null;
  if (e.projectId) {
    const [project] = await db
      .select({ name: projectsTable.name })
      .from(projectsTable)
      .where(eq(projectsTable.id, e.projectId));
    projectName = project?.name ?? null;
  }
  return {
    id: e.id,
    title: e.title,
    amount: parseFloat(e.amount as string),
    category: e.category,
    projectId: e.projectId ?? null,
    projectName,
    date: e.date,
    description: e.description,
    createdAt: e.createdAt.toISOString(),
  };
}

router.get("/", async (req, res) => {
  try {
    const params = req.query as { projectId?: string; category?: string };
    let rows = await db.select().from(expensesTable).orderBy(expensesTable.date);
    if (params.projectId) {
      const pid = parseInt(params.projectId);
      rows = rows.filter((r) => r.projectId === pid);
    }
    if (params.category) {
      rows = rows.filter((r) => r.category === params.category);
    }
    const result = await Promise.all(rows.map(toExpenseJson));
    res.json(result);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch expenses" });
  }
});

router.post("/", async (req, res) => {
  try {
    const parsed = CreateExpenseBody.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error.message });
    }
    const data = parsed.data;
    const [expense] = await db
      .insert(expensesTable)
      .values({
        title: data.title,
        amount: String(data.amount),
        category: data.category,
        projectId: data.projectId ?? null,
        date: data.date,
        description: data.description ?? "",
      })
      .returning();
    await db.insert(activitiesTable).values({
      type: "expense_added",
      description: `Expense recorded: ${expense.title} - ₹${parseFloat(expense.amount as string).toLocaleString()}`,
    });
    res.status(201).json(await toExpenseJson(expense));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to create expense" });
  }
});

router.get("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [expense] = await db.select().from(expensesTable).where(eq(expensesTable.id, id));
    if (!expense) return res.status(404).json({ error: "Expense not found" });
    res.json(await toExpenseJson(expense));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch expense" });
  }
});

router.patch("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const parsed = UpdateExpenseBody.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error.message });
    }
    const data = parsed.data;
    const updateData: Record<string, unknown> = {};
    if (data.title !== undefined) updateData.title = data.title;
    if (data.amount !== undefined) updateData.amount = String(data.amount);
    if (data.category !== undefined) updateData.category = data.category;
    if (data.projectId !== undefined) updateData.projectId = data.projectId;
    if (data.date !== undefined) updateData.date = data.date;
    if (data.description !== undefined) updateData.description = data.description;

    const [updated] = await db
      .update(expensesTable)
      .set(updateData)
      .where(eq(expensesTable.id, id))
      .returning();
    if (!updated) return res.status(404).json({ error: "Expense not found" });
    res.json(await toExpenseJson(updated));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to update expense" });
  }
});

router.delete("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [deleted] = await db
      .delete(expensesTable)
      .where(eq(expensesTable.id, id))
      .returning();
    if (!deleted) return res.status(404).json({ error: "Expense not found" });
    res.status(204).send();
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to delete expense" });
  }
});

export default router;
