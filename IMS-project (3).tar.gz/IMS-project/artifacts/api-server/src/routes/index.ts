import { Router, type IRouter } from "express";
import healthRouter from "./health";
import dashboardRouter from "./dashboard";
import clientsRouter from "./clients";
import projectsRouter from "./projects";
import employeesRouter from "./employees";
import materialsRouter from "./materials";
import expensesRouter from "./expenses";
import invoicesRouter from "./invoices";
import reportsRouter from "./reports";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/dashboard", dashboardRouter);
router.use("/clients", clientsRouter);
router.use("/projects", projectsRouter);
router.use("/employees", employeesRouter);
router.use("/materials", materialsRouter);
router.use("/expenses", expensesRouter);
router.use("/invoices", invoicesRouter);
router.use("/reports", reportsRouter);

export default router;
