import { Router } from "express";
import { db } from "@workspace/db";
import { invoicesTable, clientsTable, projectsTable, activitiesTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import {
  CreateInvoiceBody,
  UpdateInvoiceBody,
} from "@workspace/api-zod";

const router = Router();

async function toInvoiceJson(inv: typeof invoicesTable.$inferSelect) {
  const [client] = await db
    .select({ name: clientsTable.name })
    .from(clientsTable)
    .where(eq(clientsTable.id, inv.clientId));

  let projectName: string | null = null;
  if (inv.projectId) {
    const [project] = await db
      .select({ name: projectsTable.name })
      .from(projectsTable)
      .where(eq(projectsTable.id, inv.projectId));
    projectName = project?.name ?? null;
  }

  const amount = parseFloat(inv.amount as string);
  const taxRate = parseFloat(inv.taxRate as string);
  const taxAmount = amount * (taxRate / 100);
  const totalAmount = amount + taxAmount;

  return {
    id: inv.id,
    invoiceNumber: inv.invoiceNumber,
    clientId: inv.clientId,
    clientName: client?.name ?? "Unknown",
    projectId: inv.projectId ?? null,
    projectName,
    amount,
    taxRate,
    taxAmount: Math.round(taxAmount * 100) / 100,
    totalAmount: Math.round(totalAmount * 100) / 100,
    status: inv.status,
    dueDate: inv.dueDate,
    issueDate: inv.issueDate,
    notes: inv.notes,
    createdAt: inv.createdAt.toISOString(),
  };
}

function generateInvoiceNumber(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const rand = Math.floor(Math.random() * 9000) + 1000;
  return `INV-${year}${month}-${rand}`;
}

router.get("/", async (req, res) => {
  try {
    const params = req.query as { status?: string; clientId?: string };
    let rows = await db.select().from(invoicesTable).orderBy(invoicesTable.createdAt);
    if (params.status) rows = rows.filter((r) => r.status === params.status);
    if (params.clientId) {
      const cid = parseInt(params.clientId);
      rows = rows.filter((r) => r.clientId === cid);
    }
    const result = await Promise.all(rows.map(toInvoiceJson));
    res.json(result);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch invoices" });
  }
});

router.post("/", async (req, res) => {
  try {
    const parsed = CreateInvoiceBody.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error.message });
    }
    const data = parsed.data;
    const [invoice] = await db
      .insert(invoicesTable)
      .values({
        invoiceNumber: generateInvoiceNumber(),
        clientId: data.clientId,
        projectId: data.projectId ?? null,
        amount: String(data.amount),
        taxRate: String(data.taxRate),
        status: data.status ?? "pending",
        dueDate: data.dueDate,
        issueDate: data.issueDate,
        notes: data.notes ?? "",
      })
      .returning();
    await db.insert(activitiesTable).values({
      type: "invoice_created",
      description: `Invoice ${invoice.invoiceNumber} generated`,
    });
    res.status(201).json(await toInvoiceJson(invoice));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to create invoice" });
  }
});

router.get("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [invoice] = await db.select().from(invoicesTable).where(eq(invoicesTable.id, id));
    if (!invoice) return res.status(404).json({ error: "Invoice not found" });
    res.json(await toInvoiceJson(invoice));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch invoice" });
  }
});

router.patch("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const parsed = UpdateInvoiceBody.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error.message });
    }
    const data = parsed.data;
    const updateData: Record<string, unknown> = {};
    if (data.clientId !== undefined) updateData.clientId = data.clientId;
    if (data.projectId !== undefined) updateData.projectId = data.projectId;
    if (data.amount !== undefined) updateData.amount = String(data.amount);
    if (data.taxRate !== undefined) updateData.taxRate = String(data.taxRate);
    if (data.status !== undefined) updateData.status = data.status;
    if (data.dueDate !== undefined) updateData.dueDate = data.dueDate;
    if (data.issueDate !== undefined) updateData.issueDate = data.issueDate;
    if (data.notes !== undefined) updateData.notes = data.notes;

    const [updated] = await db
      .update(invoicesTable)
      .set(updateData)
      .where(eq(invoicesTable.id, id))
      .returning();
    if (!updated) return res.status(404).json({ error: "Invoice not found" });

    if (data.status === "paid") {
      await db.insert(activitiesTable).values({
        type: "payment_received",
        description: `Payment received for invoice ${updated.invoiceNumber}`,
      });
    }

    res.json(await toInvoiceJson(updated));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to update invoice" });
  }
});

router.delete("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [deleted] = await db
      .delete(invoicesTable)
      .where(eq(invoicesTable.id, id))
      .returning();
    if (!deleted) return res.status(404).json({ error: "Invoice not found" });
    res.status(204).send();
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to delete invoice" });
  }
});

export default router;
