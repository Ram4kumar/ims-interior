import { Router } from "express";
import { db } from "@workspace/db";
import { projectsTable, clientsTable, activitiesTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import {
  CreateProjectBody,
  UpdateProjectBody,
  ListProjectsQueryParams,
} from "@workspace/api-zod";

const router = Router();

async function toProjectJson(p: typeof projectsTable.$inferSelect) {
  const [client] = await db
    .select({ name: clientsTable.name })
    .from(clientsTable)
    .where(eq(clientsTable.id, p.clientId));
  let employees: string[] = [];
  try {
    employees = JSON.parse(p.assignedEmployees);
  } catch {
    employees = [];
  }
  return {
    id: p.id,
    name: p.name,
    clientId: p.clientId,
    clientName: client?.name ?? "Unknown",
    status: p.status,
    startDate: p.startDate,
    endDate: p.endDate,
    budget: parseFloat(p.budget as string),
    location: p.location,
    notes: p.notes,
    assignedEmployees: employees,
    createdAt: p.createdAt.toISOString(),
  };
}

router.get("/", async (req, res) => {
  try {
    const params = req.query as { status?: string; clientId?: string };
    let rows = await db.select().from(projectsTable).orderBy(projectsTable.createdAt);

    if (params.status) {
      rows = rows.filter((r) => r.status === params.status);
    }
    if (params.clientId) {
      const cid = parseInt(params.clientId);
      rows = rows.filter((r) => r.clientId === cid);
    }

    const result = await Promise.all(rows.map(toProjectJson));
    res.json(result);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch projects" });
  }
});

router.post("/", async (req, res) => {
  try {
    const parsed = CreateProjectBody.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error.message });
    }
    const data = parsed.data;
    const [project] = await db
      .insert(projectsTable)
      .values({
        name: data.name,
        clientId: data.clientId,
        status: data.status,
        startDate: data.startDate,
        endDate: data.endDate,
        budget: String(data.budget),
        location: data.location,
        notes: data.notes ?? "",
        assignedEmployees: JSON.stringify(data.assignedEmployees ?? []),
      })
      .returning();
    await db.insert(activitiesTable).values({
      type: "project_created",
      description: `New project created: ${project.name}`,
    });
    res.status(201).json(await toProjectJson(project));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to create project" });
  }
});

router.get("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [project] = await db.select().from(projectsTable).where(eq(projectsTable.id, id));
    if (!project) return res.status(404).json({ error: "Project not found" });
    res.json(await toProjectJson(project));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch project" });
  }
});

router.patch("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const parsed = UpdateProjectBody.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error.message });
    }
    const data = parsed.data;
    const updateData: Record<string, unknown> = {};
    if (data.name !== undefined) updateData.name = data.name;
    if (data.clientId !== undefined) updateData.clientId = data.clientId;
    if (data.status !== undefined) updateData.status = data.status;
    if (data.startDate !== undefined) updateData.startDate = data.startDate;
    if (data.endDate !== undefined) updateData.endDate = data.endDate;
    if (data.budget !== undefined) updateData.budget = String(data.budget);
    if (data.location !== undefined) updateData.location = data.location;
    if (data.notes !== undefined) updateData.notes = data.notes;
    if (data.assignedEmployees !== undefined)
      updateData.assignedEmployees = JSON.stringify(data.assignedEmployees);

    const [updated] = await db
      .update(projectsTable)
      .set(updateData)
      .where(eq(projectsTable.id, id))
      .returning();
    if (!updated) return res.status(404).json({ error: "Project not found" });

    if (data.status) {
      await db.insert(activitiesTable).values({
        type: "project_updated",
        description: `Project "${updated.name}" status changed to ${data.status}`,
      });
    }

    res.json(await toProjectJson(updated));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to update project" });
  }
});

router.delete("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [deleted] = await db
      .delete(projectsTable)
      .where(eq(projectsTable.id, id))
      .returning();
    if (!deleted) return res.status(404).json({ error: "Project not found" });
    await db.insert(activitiesTable).values({
      type: "project_deleted",
      description: `Project removed: ${deleted.name}`,
    });
    res.status(204).send();
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to delete project" });
  }
});

export default router;
