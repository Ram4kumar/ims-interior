import { Router } from "express";
import { db } from "@workspace/db";
import { expensesTable, projectsTable, invoicesTable } from "@workspace/db";
import { sql, eq } from "drizzle-orm";

const router = Router();

router.get("/expense-by-category", async (req, res) => {
  try {
    const rows = await db
      .select({
        category: expensesTable.category,
        total: sql<number>`sum(amount::numeric)::float`,
      })
      .from(expensesTable)
      .groupBy(expensesTable.category)
      .orderBy(sql`sum(amount::numeric) DESC`);

    res.json(
      rows.map((r) => ({
        category: r.category,
        total: Math.round((r.total ?? 0) * 100) / 100,
      }))
    );
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch expense by category" });
  }
});

router.get("/project-completion", async (req, res) => {
  try {
    const rows = await db
      .select({
        status: projectsTable.status,
        count: sql<number>`count(*)::int`,
      })
      .from(projectsTable)
      .groupBy(projectsTable.status);

    const counts: Record<string, number> = {};
    for (const row of rows) {
      counts[row.status] = row.count;
    }
    const total = Object.values(counts).reduce((a, b) => a + b, 0);
    const completed = counts["completed"] ?? 0;

    res.json({
      total,
      completed,
      ongoing: counts["ongoing"] ?? 0,
      pending: counts["pending"] ?? 0,
      completionRate: total > 0 ? Math.round((completed / total) * 100 * 10) / 10 : 0,
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch project completion report" });
  }
});

router.get("/pending-payments", async (req, res) => {
  try {
    const rows = await db.select().from(invoicesTable);
    const pending = rows.filter((r) => r.status === "pending");
    const overdue = rows.filter((r) => r.status === "overdue");

    function calcTotal(items: typeof rows) {
      return items.reduce((s, inv) => {
        const a = parseFloat(inv.amount as string);
        const t = parseFloat(inv.taxRate as string);
        return s + a * (1 + t / 100);
      }, 0);
    }

    res.json({
      totalPending: Math.round(calcTotal(pending) * 100) / 100,
      totalOverdue: Math.round(calcTotal(overdue) * 100) / 100,
      invoiceCount: pending.length,
      overdueCount: overdue.length,
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch pending payments" });
  }
});

export default router;
