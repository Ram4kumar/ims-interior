import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard, Users, FolderKanban, UserRound, Package,
  Receipt, FileText, BarChart3, Settings, LogOut, Menu, X,
  Sun, Moon, ChevronDown
} from "lucide-react";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";

const NAV_ITEMS = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard, color: "from-violet-500 to-indigo-500", bg: "bg-violet-500/15", text: "text-violet-300" },
  { href: "/clients", label: "Clients", icon: Users, color: "from-sky-500 to-cyan-500", bg: "bg-sky-500/15", text: "text-sky-300" },
  { href: "/projects", label: "Projects", icon: FolderKanban, color: "from-emerald-500 to-teal-500", bg: "bg-emerald-500/15", text: "text-emerald-300" },
  { href: "/employees", label: "Employees", icon: UserRound, color: "from-pink-500 to-rose-500", bg: "bg-pink-500/15", text: "text-pink-300" },
  { href: "/materials", label: "Materials", icon: Package, color: "from-amber-500 to-orange-500", bg: "bg-amber-500/15", text: "text-amber-300" },
  { href: "/expenses", label: "Expenses", icon: Receipt, color: "from-red-500 to-orange-500", bg: "bg-red-500/15", text: "text-red-300" },
  { href: "/invoices", label: "Invoices", icon: FileText, color: "from-blue-500 to-indigo-500", bg: "bg-blue-500/15", text: "text-blue-300" },
  { href: "/reports", label: "Reports", icon: BarChart3, color: "from-purple-500 to-violet-500", bg: "bg-purple-500/15", text: "text-purple-300" },
  { href: "/settings", label: "Settings", icon: Settings, color: "from-slate-400 to-gray-400", bg: "bg-slate-500/15", text: "text-slate-300" },
];

export function Layout({ children }: { children: React.ReactNode }) {
  const { user, logout } = useAuth();
  const [location] = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [darkMode, setDarkMode] = useState(() =>
    document.documentElement.classList.contains("dark")
  );

  const toggleDark = () => {
    document.documentElement.classList.toggle("dark");
    setDarkMode((prev) => !prev);
  };

  const currentItem = NAV_ITEMS.find((item) =>
    location === item.href || location.startsWith(item.href + "/")
  );

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {/* Sidebar */}
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-50 flex w-64 flex-col transition-transform duration-300 lg:static lg:translate-x-0",
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        )}
        style={{ background: "linear-gradient(160deg, #0f1744 0%, #0c1535 50%, #0a1628 100%)" }}
      >
        {/* Logo */}
        <div className="flex h-16 items-center gap-3 px-5 border-b border-white/8">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500 to-indigo-600 shadow-lg shadow-violet-500/30">
            <span className="text-sm font-black text-white tracking-tight">IMS</span>
          </div>
          <div>
            <p className="text-sm font-bold text-white">Interior Mgmt</p>
            <p className="text-xs text-white/40">Management System</p>
          </div>
          <button
            className="ml-auto lg:hidden text-white/50 hover:text-white"
            onClick={() => setSidebarOpen(false)}
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-0.5">
          <p className="px-3 mb-2 text-[10px] font-semibold uppercase tracking-widest text-white/25">Navigation</p>
          {NAV_ITEMS.map((item) => {
            const active = location === item.href || location.startsWith(item.href + "/");
            return (
              <Link key={item.href} href={item.href}>
                <a
                  onClick={() => setSidebarOpen(false)}
                  className={cn(
                    "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all group",
                    active
                      ? "bg-white/10 text-white shadow-sm"
                      : "text-white/55 hover:bg-white/6 hover:text-white/85"
                  )}
                >
                  <div className={cn(
                    "flex h-7 w-7 shrink-0 items-center justify-center rounded-lg transition-all",
                    active ? `bg-gradient-to-br ${item.color} shadow-md` : `${item.bg}`
                  )}>
                    <item.icon className={cn("h-3.5 w-3.5", active ? "text-white" : item.text)} />
                  </div>
                  <span>{item.label}</span>
                  {active && <div className="ml-auto h-1.5 w-1.5 rounded-full bg-white/60" />}
                </a>
              </Link>
            );
          })}
        </nav>

        {/* User */}
        <div className="border-t border-white/8 p-4">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500 to-indigo-500 text-xs font-bold uppercase text-white shadow-lg shadow-violet-500/20">
              {user?.username?.slice(0, 2)}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-white truncate">{user?.username}</p>
              <p className="text-xs text-white/40 capitalize">{user?.role}</p>
            </div>
            <button onClick={logout} className="text-white/30 hover:text-white/70 transition-colors p-1">
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        </div>
      </aside>

      {/* Overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Main */}
      <div className="flex flex-1 flex-col overflow-hidden">
        {/* Header */}
        <header className="flex h-16 shrink-0 items-center gap-4 border-b border-border bg-card/80 backdrop-blur-sm px-4 lg:px-6">
          <button
            className="lg:hidden text-muted-foreground hover:text-foreground"
            onClick={() => setSidebarOpen(true)}
          >
            <Menu className="h-5 w-5" />
          </button>

          {/* Page title with colored dot */}
          <div className="flex items-center gap-2.5">
            {currentItem && (
              <div className={`h-2 w-2 rounded-full bg-gradient-to-r ${currentItem.color}`} />
            )}
            <h1 className="text-base font-semibold text-foreground">{currentItem?.label ?? "IMS"}</h1>
          </div>

          <div className="ml-auto flex items-center gap-2">
            <button
              onClick={toggleDark}
              className="flex h-8 w-8 items-center justify-center rounded-lg text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"
            >
              {darkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex items-center gap-2 rounded-lg px-3 py-1.5 text-sm font-medium text-muted-foreground hover:bg-muted hover:text-foreground transition-colors">
                  <div className="flex h-6 w-6 items-center justify-center rounded-lg bg-gradient-to-br from-violet-500 to-indigo-500 text-white text-xs font-bold uppercase shadow-sm">
                    {user?.username?.slice(0, 2)}
                  </div>
                  <span className="hidden sm:block">{user?.username}</span>
                  <ChevronDown className="h-3.5 w-3.5" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={logout} className="text-destructive">
                  <LogOut className="mr-2 h-4 w-4" /> Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto p-4 lg:p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
