import type { LucideIcon } from "lucide-react";

interface StatCardProps {
  label: string;
  value: string | number;
  icon: LucideIcon;
  trend?: string;
  gradient: string;
  iconBg?: string;
}

export function StatCard({ label, value, icon: Icon, trend, gradient, iconBg }: StatCardProps) {
  return (
    <div className={`relative overflow-hidden rounded-2xl p-5 text-white shadow-lg ${gradient}`}>
      {/* Decorative circles */}
      <div className="absolute -right-4 -top-4 h-24 w-24 rounded-full bg-white/10" />
      <div className="absolute -right-1 top-8 h-12 w-12 rounded-full bg-white/8" />

      <div className="relative flex items-start justify-between gap-3">
        <div className="flex-1 min-w-0">
          <p className="text-xs font-semibold uppercase tracking-wider text-white/70">{label}</p>
          <p className="mt-2 text-2xl font-black text-white leading-tight">{value}</p>
          {trend && <p className="mt-1.5 text-xs text-white/65">{trend}</p>}
        </div>
        <div className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-white/20 shadow-inner ${iconBg ?? ""}`}>
          <Icon className="h-5.5 w-5.5 text-white" />
        </div>
      </div>
    </div>
  );
}
