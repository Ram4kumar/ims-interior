import { useGetDashboardSummary, useGetMonthlyRevenue, useGetRecentActivity, useGetProjectStatusBreakdown } from "@workspace/api-client-react";
import { StatCard } from "@/components/StatCard";
import { formatCurrency } from "@/lib/utils";
import { Users, FolderKanban, TrendingUp, AlertCircle, DollarSign, Package, CheckCircle2, Clock } from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

const PIE_COLORS = ["#f59e0b", "#6366f1", "#10b981", "#f43f5e"];

const STAT_CONFIG = [
  { key: "totalClients", label: "Total Clients", icon: Users, gradient: "bg-gradient-to-br from-violet-500 to-indigo-600", trend: "Active client base" },
  { key: "totalProjects", label: "Total Projects", icon: FolderKanban, gradient: "bg-gradient-to-br from-sky-500 to-cyan-600", trend: "All time projects" },
  { key: "ongoingProjects", label: "Ongoing Projects", icon: Clock, gradient: "bg-gradient-to-br from-amber-500 to-orange-500", trend: "Currently active" },
  { key: "completedProjects", label: "Completed", icon: CheckCircle2, gradient: "bg-gradient-to-br from-emerald-500 to-teal-600", trend: "Successfully delivered" },
  { key: "totalRevenue", label: "Total Revenue", icon: TrendingUp, gradient: "bg-gradient-to-br from-green-500 to-emerald-600", currency: true, trend: "Lifetime revenue" },
  { key: "totalExpenses", label: "Total Expenses", icon: DollarSign, gradient: "bg-gradient-to-br from-red-500 to-rose-600", currency: true, trend: "All expenses" },
  { key: "pendingPayments", label: "Pending Payments", icon: AlertCircle, gradient: "bg-gradient-to-br from-pink-500 to-rose-500", currency: true, trend: "Awaiting collection" },
  { key: "lowStockMaterials", label: "Low Stock Items", icon: Package, gradient: "bg-gradient-to-br from-orange-500 to-amber-600", trend: "Need restocking" },
] as const;

function ActivityDot({ type }: { type: string }) {
  const COLORS: Record<string, string> = {
    invoice_created: "bg-blue-500",
    payment_received: "bg-emerald-500",
    project_created: "bg-violet-500",
    project_updated: "bg-amber-500",
    client_added: "bg-pink-500",
    material_added: "bg-teal-500",
    expense_added: "bg-red-500",
    employee_added: "bg-cyan-500",
  };
  return <span className={`h-2 w-2 rounded-full shrink-0 ${COLORS[type] ?? "bg-muted-foreground"}`} />;
}

export default function Dashboard() {
  const { data: summary, isLoading: sumLoading } = useGetDashboardSummary();
  const { data: revenue, isLoading: revLoading } = useGetMonthlyRevenue();
  const { data: activity, isLoading: actLoading } = useGetRecentActivity();
  const { data: breakdown, isLoading: bdLoading } = useGetProjectStatusBreakdown();

  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {sumLoading
          ? Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="h-28 rounded-2xl" />)
          : STAT_CONFIG.map((cfg) => {
              const raw = summary ? (summary as unknown as Record<string, number>)[cfg.key] ?? 0 : 0;
              const isCurrency = "currency" in cfg && cfg.currency;
              return (
                <StatCard
                  key={cfg.key}
                  label={cfg.label}
                  value={isCurrency ? formatCurrency(raw) : raw}
                  icon={cfg.icon}
                  gradient={cfg.gradient}
                  trend={cfg.trend}
                />
              );
            })}
      </div>

      <div className="grid gap-5 lg:grid-cols-3">
        {/* Revenue Chart */}
        <Card className="lg:col-span-2 overflow-hidden">
          <CardHeader className="pb-2 flex flex-row items-center justify-between">
            <CardTitle className="text-sm font-semibold">Revenue vs Expenses</CardTitle>
            <div className="flex gap-3 text-xs">
              <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-full bg-violet-500" />Revenue</span>
              <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-full bg-amber-500" />Expenses</span>
            </div>
          </CardHeader>
          <CardContent className="pb-3">
            {revLoading ? <Skeleton className="h-56 w-full" /> : (
              <ResponsiveContainer width="100%" height={220}>
                <AreaChart data={revenue ?? []}>
                  <defs>
                    <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#7c3aed" stopOpacity={0.25} />
                      <stop offset="95%" stopColor="#7c3aed" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="expGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.25} />
                      <stop offset="95%" stopColor="#f59e0b" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="month" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} />
                  <YAxis tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`} />
                  <Tooltip
                    contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 12, fontSize: 12, boxShadow: "0 10px 40px rgba(0,0,0,0.15)" }}
                    formatter={(v: number) => [formatCurrency(v), ""]}
                  />
                  <Area type="monotone" dataKey="revenue" stroke="#7c3aed" strokeWidth={2.5} fill="url(#revGrad)" name="Revenue" />
                  <Area type="monotone" dataKey="expenses" stroke="#f59e0b" strokeWidth={2.5} fill="url(#expGrad)" name="Expenses" />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        {/* Project Status Pie */}
        <Card className="overflow-hidden">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold">Project Status</CardTitle>
          </CardHeader>
          <CardContent>
            {bdLoading ? <Skeleton className="h-56 w-full" /> : (
              <div className="space-y-4">
                <ResponsiveContainer width="100%" height={160}>
                  <PieChart>
                    <Pie data={breakdown ?? []} dataKey="count" nameKey="status" cx="50%" cy="50%" outerRadius={75} innerRadius={45} strokeWidth={3} stroke="hsl(var(--card))">
                      {(breakdown ?? []).map((_, index) => (
                        <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 10, fontSize: 12 }} />
                  </PieChart>
                </ResponsiveContainer>
                <div className="space-y-2">
                  {(breakdown ?? []).map((entry, i) => (
                    <div key={entry.status} className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2">
                        <span className="h-2.5 w-2.5 rounded-full shrink-0" style={{ background: PIE_COLORS[i % PIE_COLORS.length] }} />
                        <span className="text-muted-foreground capitalize">{entry.status}</span>
                      </div>
                      <span className="font-semibold text-foreground">{entry.count}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card className="overflow-hidden">
        <CardHeader className="pb-2 border-b border-border">
          <CardTitle className="text-sm font-semibold">Recent Activity</CardTitle>
        </CardHeader>
        <CardContent className="pt-3 px-0">
          {actLoading ? (
            <div className="space-y-2 px-6">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}</div>
          ) : (activity ?? []).length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-8">No recent activity</p>
          ) : (
            <div>
              {(activity ?? []).map((a, idx) => (
                <div key={a.id} className={`flex items-center gap-3 px-6 py-3 hover:bg-muted/40 transition-colors ${idx < (activity ?? []).length - 1 ? "border-b border-border/50" : ""}`}>
                  <ActivityDot type={a.type} />
                  <p className="flex-1 text-sm text-foreground">{a.description}</p>
                  <p className="text-xs text-muted-foreground whitespace-nowrap bg-muted px-2 py-0.5 rounded-full">
                    {new Date(a.createdAt).toLocaleDateString("en-IN", { day: "2-digit", month: "short" })}
                  </p>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
