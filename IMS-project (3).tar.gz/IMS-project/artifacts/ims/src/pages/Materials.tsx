import { useState } from "react";
import { useListMaterials, useCreateMaterial, useUpdateMaterial, useDeleteMaterial, getListMaterialsQueryKey } from "@workspace/api-client-react";
import type { Material } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { PageHeader } from "@/components/PageHeader";
import { EmptyState } from "@/components/EmptyState";
import { Skeleton } from "@/components/ui/skeleton";
import { formatCurrency } from "@/lib/utils";
import { Package, Plus, Pencil, Trash2, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";

type FormData = { name: string; quantity: string; unit: string; unitPrice: string; supplierName: string; lowStockThreshold: string };
const empty: FormData = { name: "", quantity: "", unit: "pcs", unitPrice: "", supplierName: "", lowStockThreshold: "10" };

const MATERIAL_GRADIENTS = [
  "from-amber-500 to-orange-500",
  "from-teal-500 to-cyan-600",
  "from-violet-500 to-purple-600",
  "from-emerald-500 to-green-600",
  "from-sky-500 to-blue-600",
  "from-rose-500 to-pink-600",
];

export default function Materials() {
  const qc = useQueryClient();
  const [showLowStock, setShowLowStock] = useState(false);
  const { data: materials, isLoading } = useListMaterials({ lowStock: showLowStock || undefined });
  const createMut = useCreateMaterial();
  const updateMut = useUpdateMaterial();
  const deleteMut = useDeleteMaterial();
  const [dialog, setDialog] = useState<{ open: boolean; editing: Material | null }>({ open: false, editing: null });
  const [form, setForm] = useState<FormData>(empty);
  const [deleteId, setDeleteId] = useState<number | null>(null);

  const invalidate = () => qc.invalidateQueries({ queryKey: getListMaterialsQueryKey() });
  const openCreate = () => { setForm(empty); setDialog({ open: true, editing: null }); };
  const openEdit = (m: Material) => {
    setForm({ name: m.name, quantity: String(m.quantity), unit: m.unit, unitPrice: String(m.unitPrice), supplierName: m.supplierName, lowStockThreshold: String(m.lowStockThreshold) });
    setDialog({ open: true, editing: m });
  };

  const handleSave = () => {
    const payload = { name: form.name, quantity: parseInt(form.quantity) || 0, unit: form.unit, unitPrice: parseFloat(form.unitPrice) || 0, supplierName: form.supplierName, lowStockThreshold: parseInt(form.lowStockThreshold) || 10 };
    if (dialog.editing) {
      updateMut.mutate({ id: dialog.editing.id, data: payload }, { onSuccess: () => { invalidate(); setDialog({ open: false, editing: null }); } });
    } else {
      createMut.mutate({ data: payload }, { onSuccess: () => { invalidate(); setDialog({ open: false, editing: null }); } });
    }
  };

  const setField = (k: keyof FormData) => (e: React.ChangeEvent<HTMLInputElement>) => setForm((p) => ({ ...p, [k]: e.target.value }));
  const lowCount = (materials ?? []).filter((m) => m.isLowStock).length;
  const totalValue = (materials ?? []).reduce((s, m) => s + m.quantity * m.unitPrice, 0);

  return (
    <div>
      <PageHeader
        title="Materials"
        subtitle="Inventory management & stock tracking"
        icon={Package}
        gradient="bg-gradient-to-br from-amber-500 via-orange-500 to-red-500"
        stats={[
          { label: "Total Items", value: materials?.length ?? 0 },
          { label: "Low Stock", value: lowCount },
          { label: "Total Value", value: formatCurrency(totalValue) },
        ]}
        action={
          <Button onClick={openCreate} className="bg-white/20 hover:bg-white/30 text-white border-0 backdrop-blur-sm shadow-none">
            <Plus className="mr-2 h-4 w-4" /> Add Material
          </Button>
        }
      />

      {lowCount > 0 && (
        <button
          onClick={() => setShowLowStock((v) => !v)}
          className={cn("flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold mb-5 transition-all shadow-sm",
            showLowStock
              ? "bg-amber-500 text-white shadow-amber-500/30 shadow-md"
              : "bg-amber-100 text-amber-700 hover:bg-amber-200 dark:bg-amber-950/50 dark:text-amber-300 dark:hover:bg-amber-950"
          )}>
          <AlertTriangle className="h-4 w-4" />
          {showLowStock ? "Show all items" : `${lowCount} low stock alert${lowCount > 1 ? "s" : ""} — click to filter`}
        </button>
      )}

      {isLoading ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-48 rounded-2xl" />)}
        </div>
      ) : (materials ?? []).length === 0 ? (
        <EmptyState icon={Package} title="No materials found" description="Add materials to track your inventory"
          action={<Button onClick={openCreate}><Plus className="mr-2 h-4 w-4" />Add Material</Button>} />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {(materials ?? []).map((m, idx) => {
            const grad = m.isLowStock ? "from-red-500 to-rose-600" : MATERIAL_GRADIENTS[idx % MATERIAL_GRADIENTS.length];
            const stockPct = Math.min(100, Math.round((m.quantity / (m.lowStockThreshold * 3)) * 100));
            return (
              <div key={m.id} className={cn("rounded-2xl border bg-card shadow-sm hover:shadow-lg transition-all duration-200 group overflow-hidden", m.isLowStock ? "border-amber-300 dark:border-amber-700" : "border-border")}>
                <div className={`h-1.5 bg-gradient-to-r ${grad}`} />
                <div className="p-5">
                  <div className="flex items-start justify-between gap-2 mb-4">
                    <div className="flex items-center gap-3">
                      <div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br ${grad} shadow-md`}>
                        <Package className="h-4.5 w-4.5 text-white" />
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <h3 className="font-bold text-foreground text-sm leading-tight">{m.name}</h3>
                          {m.isLowStock && <AlertTriangle className="h-3.5 w-3.5 text-amber-500 shrink-0" />}
                        </div>
                        <p className="text-xs text-muted-foreground">{m.supplierName}</p>
                      </div>
                    </div>
                    <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button onClick={() => openEdit(m)} className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground"><Pencil className="h-3.5 w-3.5" /></button>
                      <button onClick={() => setDeleteId(m.id)} className="p-1.5 rounded-lg hover:bg-red-50 dark:hover:bg-red-950/30 text-muted-foreground hover:text-red-600"><Trash2 className="h-3.5 w-3.5" /></button>
                    </div>
                  </div>

                  {/* Stock bar */}
                  <div className="mb-3">
                    <div className="flex justify-between text-xs mb-1.5">
                      <span className="text-muted-foreground">Stock Level</span>
                      <span className={cn("font-bold", m.isLowStock ? "text-amber-600 dark:text-amber-400" : "text-foreground")}>{m.quantity} {m.unit}</span>
                    </div>
                    <div className="h-2 rounded-full bg-muted overflow-hidden">
                      <div className={`h-full rounded-full transition-all bg-gradient-to-r ${m.isLowStock ? "from-red-500 to-amber-500" : grad}`} style={{ width: `${Math.max(4, stockPct)}%` }} />
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">Alert below {m.lowStockThreshold} {m.unit}</p>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-sm pt-3 border-t border-border">
                    <div>
                      <p className="text-xs text-muted-foreground">Unit Price</p>
                      <p className="font-semibold text-foreground">{formatCurrency(m.unitPrice)}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Total Value</p>
                      <p className="font-bold text-foreground">{formatCurrency(m.quantity * m.unitPrice)}</p>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <Dialog open={dialog.open} onOpenChange={(open) => setDialog({ open, editing: null })}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <div className="h-6 w-1 rounded-full bg-gradient-to-b from-amber-500 to-orange-500" />
              {dialog.editing ? "Edit Material" : "Add Material"}
            </DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5 col-span-2"><Label>Material Name</Label><Input value={form.name} onChange={setField("name")} placeholder="Material name" /></div>
            <div className="space-y-1.5"><Label>Quantity</Label><Input type="number" value={form.quantity} onChange={setField("quantity")} placeholder="0" /></div>
            <div className="space-y-1.5"><Label>Unit</Label><Input value={form.unit} onChange={setField("unit")} placeholder="pcs, sq ft, m, kg…" /></div>
            <div className="space-y-1.5"><Label>Unit Price (INR)</Label><Input type="number" value={form.unitPrice} onChange={setField("unitPrice")} placeholder="0" /></div>
            <div className="space-y-1.5"><Label>Low Stock Threshold</Label><Input type="number" value={form.lowStockThreshold} onChange={setField("lowStockThreshold")} placeholder="10" /></div>
            <div className="space-y-1.5 col-span-2"><Label>Supplier Name</Label><Input value={form.supplierName} onChange={setField("supplierName")} placeholder="Supplier company name" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialog({ open: false, editing: null })}>Cancel</Button>
            <Button onClick={handleSave} disabled={createMut.isPending || updateMut.isPending}
              className="bg-gradient-to-r from-amber-500 to-orange-500 text-white border-0">
              {dialog.editing ? "Update" : "Add"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={deleteId !== null} onOpenChange={() => setDeleteId(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Delete Material</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">This will permanently remove this material record.</p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteId(null)}>Cancel</Button>
            <Button variant="destructive" onClick={() => { if (deleteId) deleteMut.mutate({ id: deleteId }, { onSuccess: () => { invalidate(); setDeleteId(null); } }); }} disabled={deleteMut.isPending}>Delete</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
