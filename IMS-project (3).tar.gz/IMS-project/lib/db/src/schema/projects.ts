import { pgTable, serial, text, decimal, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const projectsTable = pgTable("projects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  clientId: integer("client_id").notNull(),
  status: text("status").notNull().default("pending"),
  startDate: text("start_date").notNull(),
  endDate: text("end_date").notNull(),
  budget: decimal("budget", { precision: 12, scale: 2 }).notNull().default("0"),
  location: text("location").notNull().default(""),
  notes: text("notes").notNull().default(""),
  assignedEmployees: text("assigned_employees").notNull().default("[]"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertProjectSchema = createInsertSchema(projectsTable).omit({ id: true, createdAt: true });
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projectsTable.$inferSelect;
