/**
 * Seed script — populates the database with realistic sample data.
 * Run: pnpm --filter @workspace/db run seed
 */
import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";
import * as schema from "./schema";

const { Pool } = pg;

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set. See .env.example for help.");
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const db = drizzle(pool, { schema });

async function seed() {
  console.log("🌱 Seeding database…");

  // ── Clients ──────────────────────────────────────────────────────────────
  const clients = await db
    .insert(schema.clientsTable)
    .values([
      { name: "Priya Sharma", phone: "9876543210", email: "priya.sharma@email.com", address: "14, MG Road, Bengaluru 560001", requirements: "Modern minimalist 3BHK renovation", budget: "1500000" },
      { name: "Rahul Mehta", phone: "9812345678", email: "rahul.mehta@email.com", address: "7, Bandra West, Mumbai 400050", requirements: "Scandinavian style living room & kitchen", budget: "800000" },
      { name: "Ananya Iyer", phone: "9765432109", email: "ananya.iyer@email.com", address: "22, Anna Nagar, Chennai 600040", requirements: "Full villa interior from scratch", budget: "3500000" },
      { name: "Vikram Patel", phone: "9723456789", email: "vikram.patel@email.com", address: "9, C-Scheme, Jaipur 302001", requirements: "Office interior design — 3000 sq ft", budget: "2000000" },
      { name: "Meera Nair", phone: "9698765432", email: "meera.nair@email.com", address: "45, Jubilee Hills, Hyderabad 500033", requirements: "Luxury master bedroom & bathrooms", budget: "600000" },
      { name: "Arjun Kapoor", phone: "9654321098", email: "arjun.kapoor@email.com", address: "3, South Extension, New Delhi 110049", requirements: "Contemporary 4BHK with home office", budget: "2500000" },
    ])
    .returning();
  console.log(`  ✓ ${clients.length} clients`);

  // ── Employees ─────────────────────────────────────────────────────────────
  const employees = await db
    .insert(schema.employeesTable)
    .values([
      { name: "Sneha Reddy", email: "sneha.reddy@ims.com", phone: "9811223344", role: "Lead Designer", department: "Design", salary: "85000", joinDate: "2021-03-15", status: "active" },
      { name: "Karan Bose", email: "karan.bose@ims.com", phone: "9822334455", role: "Project Manager", department: "Operations", salary: "75000", joinDate: "2020-07-01", status: "active" },
      { name: "Divya Menon", email: "divya.menon@ims.com", phone: "9833445566", role: "Interior Architect", department: "Design", salary: "70000", joinDate: "2022-01-10", status: "active" },
      { name: "Rohit Kumar", email: "rohit.kumar@ims.com", phone: "9844556677", role: "Site Supervisor", department: "Execution", salary: "55000", joinDate: "2021-08-20", status: "active" },
      { name: "Pooja Joshi", email: "pooja.joshi@ims.com", phone: "9855667788", role: "Accountant", department: "Finance", salary: "60000", joinDate: "2020-11-05", status: "active" },
      { name: "Amit Sinha", email: "amit.sinha@ims.com", phone: "9866778899", role: "Sales Executive", department: "Sales", salary: "50000", joinDate: "2023-02-14", status: "active" },
      { name: "Neha Gupta", email: "neha.gupta@ims.com", phone: "9877889900", role: "Junior Designer", department: "Design", salary: "40000", joinDate: "2023-06-01", status: "inactive" },
    ])
    .returning();
  console.log(`  ✓ ${employees.length} employees`);

  // ── Projects ──────────────────────────────────────────────────────────────
  const projects = await db
    .insert(schema.projectsTable)
    .values([
      { name: "Sharma Residence Renovation", clientId: clients[0].id, status: "ongoing", startDate: "2025-01-15", endDate: "2025-06-30", budget: "1400000", location: "14, MG Road, Bengaluru", notes: "Phase 1: living room & kitchen", assignedEmployees: JSON.stringify(["Sneha Reddy", "Rohit Kumar"]) },
      { name: "Mehta Living Room Makeover", clientId: clients[1].id, status: "completed", startDate: "2024-08-01", endDate: "2024-11-30", budget: "750000", location: "7, Bandra West, Mumbai", notes: "Scandinavian theme with custom furniture", assignedEmployees: JSON.stringify(["Divya Menon", "Rohit Kumar"]) },
      { name: "Iyer Villa Full Interior", clientId: clients[2].id, status: "pending", startDate: "2025-06-01", endDate: "2026-01-31", budget: "3200000", location: "22, Anna Nagar, Chennai", notes: "Complete villa from scratch — awaiting client sign-off", assignedEmployees: JSON.stringify(["Sneha Reddy", "Karan Bose", "Divya Menon"]) },
      { name: "Patel Office Fit-Out", clientId: clients[3].id, status: "ongoing", startDate: "2025-02-10", endDate: "2025-07-15", budget: "1850000", location: "9, C-Scheme, Jaipur", notes: "Open office + 5 cabins + boardroom", assignedEmployees: JSON.stringify(["Divya Menon", "Rohit Kumar", "Amit Sinha"]) },
      { name: "Nair Master Suite", clientId: clients[4].id, status: "completed", startDate: "2024-10-01", endDate: "2025-01-15", budget: "580000", location: "45, Jubilee Hills, Hyderabad", notes: "Luxury bedroom + 2 bathrooms", assignedEmployees: JSON.stringify(["Sneha Reddy"]) },
      { name: "Kapoor Contemporary Home", clientId: clients[5].id, status: "pending", startDate: "2025-07-01", endDate: "2026-03-31", budget: "2400000", location: "3, South Extension, New Delhi", notes: "4BHK + dedicated home office + study", assignedEmployees: JSON.stringify(["Karan Bose", "Divya Menon"]) },
    ])
    .returning();
  console.log(`  ✓ ${projects.length} projects`);

  // ── Materials ─────────────────────────────────────────────────────────────
  await db
    .insert(schema.materialsTable)
    .values([
      { name: "Italian Marble Flooring", quantity: 240, unit: "sq ft", unitPrice: "350", supplierName: "Raj Stones Pvt Ltd", lowStockThreshold: 50 },
      { name: "Teak Wood Planks", quantity: 8, unit: "planks", unitPrice: "4500", supplierName: "Karnataka Timber Co", lowStockThreshold: 15 },
      { name: "Gypsum Board (12mm)", quantity: 180, unit: "sheets", unitPrice: "620", supplierName: "Saint-Gobain India", lowStockThreshold: 30 },
      { name: "Acrylic Emulsion Paint (White)", quantity: 6, unit: "buckets", unitPrice: "2800", supplierName: "Asian Paints Dealer", lowStockThreshold: 10 },
      { name: "Recessed LED Spotlights", quantity: 85, unit: "pcs", unitPrice: "450", supplierName: "Havells Lighting", lowStockThreshold: 20 },
      { name: "Designer Wallpaper Rolls", quantity: 22, unit: "rolls", unitPrice: "1800", supplierName: "Nilaya by Asian Paints", lowStockThreshold: 5 },
      { name: "Stainless Steel Hardware Set", quantity: 40, unit: "sets", unitPrice: "1200", supplierName: "Dorset Hardware", lowStockThreshold: 10 },
      { name: "Vinyl Flooring (Wood Finish)", quantity: 320, unit: "sq ft", unitPrice: "95", supplierName: "Floortek India", lowStockThreshold: 60 },
    ]);
  console.log("  ✓ 8 materials");

  // ── Expenses ──────────────────────────────────────────────────────────────
  await db
    .insert(schema.expensesTable)
    .values([
      { title: "Italian Marble — Sharma Residence", amount: "84000", category: "Materials", projectId: projects[0].id, date: "2025-01-20", description: "240 sq ft Italian marble for living + dining" },
      { title: "Labour — Mehta Project Completion", amount: "95000", category: "Labour", projectId: projects[1].id, date: "2024-11-25", description: "Final labour billing for Mehta project" },
      { title: "Office Furniture Purchase", amount: "38000", category: "Office", projectId: null, date: "2025-02-01", description: "Work stations and chairs for design studio" },
      { title: "Site Transport — Patel Office", amount: "12500", category: "Transport", projectId: projects[3].id, date: "2025-02-15", description: "Material delivery and crew transport" },
      { title: "CAD Software Subscription", amount: "24000", category: "Technology", projectId: null, date: "2025-01-05", description: "Annual AutoCAD + 3ds Max subscription" },
      { title: "Electrical Fixtures — Sharma", amount: "67000", category: "Materials", projectId: projects[0].id, date: "2025-03-10", description: "LED panels, switches, and wiring" },
      { title: "Gypsum & Plaster Work — Patel", amount: "48000", category: "Labour", projectId: projects[3].id, date: "2025-03-20", description: "False ceiling and partition work" },
      { title: "Client Event — Portfolio Launch", amount: "55000", category: "Marketing", projectId: null, date: "2025-03-28", description: "Venue + catering for portfolio showcase event" },
    ]);
  console.log("  ✓ 8 expenses");

  // ── Invoices ──────────────────────────────────────────────────────────────
  await db
    .insert(schema.invoicesTable)
    .values([
      { invoiceNumber: "INV-2025-001", clientId: clients[0].id, projectId: projects[0].id, amount: "700000", taxRate: "18", status: "paid", issueDate: "2025-01-31", dueDate: "2025-02-28", notes: "50% advance — Sharma Residence Phase 1" },
      { invoiceNumber: "INV-2025-002", clientId: clients[1].id, projectId: projects[1].id, amount: "750000", taxRate: "18", status: "paid", issueDate: "2024-12-05", dueDate: "2024-12-31", notes: "Final payment — Mehta Living Room" },
      { invoiceNumber: "INV-2025-003", clientId: clients[3].id, projectId: projects[3].id, amount: "925000", taxRate: "18", status: "pending", issueDate: "2025-02-28", dueDate: "2025-03-31", notes: "50% advance — Patel Office Fit-Out" },
      { invoiceNumber: "INV-2025-004", clientId: clients[4].id, projectId: projects[4].id, amount: "580000", taxRate: "18", status: "paid", issueDate: "2025-01-20", dueDate: "2025-02-15", notes: "Full payment — Nair Master Suite" },
      { invoiceNumber: "INV-2025-005", clientId: clients[0].id, projectId: projects[0].id, amount: "700000", taxRate: "18", status: "pending", issueDate: "2025-04-01", dueDate: "2025-04-30", notes: "Balance payment — Sharma Residence" },
      { invoiceNumber: "INV-2025-006", clientId: clients[2].id, projectId: projects[2].id, amount: "800000", taxRate: "18", status: "overdue", issueDate: "2025-03-01", dueDate: "2025-03-31", notes: "Advance — Iyer Villa (30%)" },
    ]);
  console.log("  ✓ 6 invoices");

  // ── Activities ────────────────────────────────────────────────────────────
  await db
    .insert(schema.activitiesTable)
    .values([
      { type: "client_added", description: "New client Arjun Kapoor added for contemporary home project" },
      { type: "invoice_created", description: "Invoice INV-2025-006 generated for Ananya Iyer — ₹9,44,000" },
      { type: "project_updated", description: "Sharma Residence project updated: Phase 2 started" },
      { type: "payment_received", description: "Payment received from Meera Nair — ₹6,84,400 (INV-2025-004)" },
      { type: "material_added", description: "New material added: Designer Wallpaper Rolls — 22 rolls in stock" },
      { type: "expense_added", description: "Marketing expense recorded: Client Portfolio Launch Event — ₹55,000" },
      { type: "project_created", description: "New project created: Kapoor Contemporary Home" },
      { type: "employee_added", description: "New employee Amit Sinha joined Sales department" },
    ]);
  console.log("  ✓ 8 activity entries");

  await pool.end();
  console.log("\n✅ Database seeded successfully!");
}

seed().catch((err) => {
  console.error("❌ Seed failed:", err);
  pool.end();
  process.exit(1);
});
