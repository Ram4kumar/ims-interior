# IMS — Interior Management System

A full-stack Interior Management System for interior design firms to manage clients, projects, employees, materials, expenses, invoices, and reports.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080)
- `pnpm --filter @workspace/ims run dev` — run the frontend (port 26217)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React 19 + Vite, Tailwind CSS v4, shadcn/ui, Recharts, React Query, Wouter
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/ims/` — React frontend (all pages, components, contexts)
- `artifacts/api-server/src/routes/` — Express route handlers
- `lib/db/src/schema/` — Drizzle ORM schema (source of truth)
- `lib/api-spec/` — OpenAPI spec (source of truth for API contracts)
- `lib/api-client-react/src/generated/api.ts` — Generated hooks & types (do not edit)

## Architecture decisions

- Contract-first API: OpenAPI spec drives codegen of React Query hooks and Zod schemas
- Auth is localStorage-based (simple demo auth, not JWT/session-based)
- All money values stored as integers/floats in INR; formatted with Intl.NumberFormat
- Dark mode via Tailwind CSS v4 `.dark` class toggled on `<html>` at runtime
- Sidebar navigation is fixed on desktop, slide-over drawer on mobile

## Product

- **Login** — Credential-based auth (admin/admin123, employee/emp123)
- **Dashboard** — KPI cards, revenue vs expense area chart, project status pie chart, recent activity feed
- **Clients** — Card grid with search, full CRUD
- **Projects** — Tabbed by status (all/pending/ongoing/completed), full CRUD
- **Employees** — Card grid with department + status badges, full CRUD
- **Materials** — Inventory cards with low-stock alerts, full CRUD
- **Expenses** — Table with category filter and totals, full CRUD
- **Invoices** — Table tabbed by status, GST calculation preview, full CRUD
- **Reports** — Expense breakdown pie, project completion bars, revenue/expense bar chart, pending payments summary
- **Settings** — Profile info, credentials hint, system info

## User preferences

- INR currency formatting throughout
- Indian date format (DD MMM YYYY)

## Gotchas

- Run `pnpm --filter @workspace/api-spec run codegen` after any OpenAPI spec changes
- Do not import directly from `lib/api-client-react/src/generated/` — import from the package alias `@workspace/api-client-react`
- The `f()` pattern for form handlers must use `setField()`/`setSelect()` split to satisfy TypeScript (avoids void union errors)

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
